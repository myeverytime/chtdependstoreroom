//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CardFile.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CARDFILE_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_ACCOUNT                     129
#define IDD_CONTACT                     130
#define IDB_BITMAP1                     131
#define IDB_SAMPLE                      131
#define IDC_ACCOUNT_LIST                1000
#define IDC_CONTACT_LIST                1001
#define IDC_ADD_ACCOUNT                 1002
#define IDC_EDIT_ACCOUNT                1003
#define IDC_DELETE_ACCOUNT              1004
#define IDC_ADD_CONTACT                 1005
#define IDC_ACCNT_ID                    1005
#define IDC_EDIT_CONTACT                1006
#define IDC_ACCNT_NAME                  1006
#define IDC_DELETE_CONTACT              1007
#define IDC_ACCNT_ADDRESS               1007
#define IDC_ACCNT_PHONE1                1008
#define IDC_ACCNT_PHONE2                1009
#define IDC_ACCNT_EMAIL                 1010
#define IDC_ACCNT_NOTE                  1011
#define IDC_OK                          1012
#define IDC_CANCEL                      1013
#define IDC_CONT_NAME                   1014
#define IDC_CONT_TITLE                  1015
#define IDC_CONT_PHONE                  1016
#define IDC_CONT_EXTN                   1017
#define IDC_CONT_EMAIL                  1018
#define IDC_CONT_NOTE                   1019
#define IDC_PHOTO_ID                    1020
#define IDC_GET_IMAGE                   1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
